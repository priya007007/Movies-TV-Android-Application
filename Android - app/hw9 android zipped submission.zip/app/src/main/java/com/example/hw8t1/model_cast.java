package com.example.hw8t1;

public class model_cast {
    String profile;
    String name;
    public model_cast(String profile, String name){
        this.profile = profile;
        this.name =name;
    }
    public String getProfile_Path() {
        return profile;
    }

    public String getName() {
        return name;
    }
}
